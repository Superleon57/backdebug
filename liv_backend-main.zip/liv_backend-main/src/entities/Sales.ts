export class Sales {
  id: string;
  shopId: string;
  productId: string;
  quantity: number;
}
