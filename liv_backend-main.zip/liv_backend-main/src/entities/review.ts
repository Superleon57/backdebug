export class Review {
  id: string;
  comment: string;
  rate: number;
  orderId: string;
}
