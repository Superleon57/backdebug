export class Config {
  api_key: string;
  type: string;
  url: string;
}

