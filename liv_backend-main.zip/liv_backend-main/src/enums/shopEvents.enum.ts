export enum ShopEvents {
}

export enum ShopEmits {
  NEW_ORDER,
}
