export enum PaymentResult {
  SUCCESS = 'success',
  FAILED = 'failed',
  CANCELED = 'canceled',
}
