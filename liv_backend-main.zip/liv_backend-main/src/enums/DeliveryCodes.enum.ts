export enum DeliveryCodes {
  TAKING = "TAKING",
  DELIVERY = "DELIVERY",
}
