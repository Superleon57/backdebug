export enum Roles {
  ADMIN = "ADMIN",
  USER = "Role.user",
  LIVREUR = "Role.livreur",
  COMMERCANT = "COMMERCANT",
  SUPERVISOR = "SUPERVISOR",
}
