export enum CustomerEvents {
}

export enum CustomerEmits {
  NEW_ORDER,
}
