export enum OrderEmits {
  NEW_ORDER = 'ORDER:NEW',
  TAKEN = 'ORDER:TAKEN',
  READY = 'ORDER:ready',
  DELIVERED = 'ORDER:DELIVERED',
}
