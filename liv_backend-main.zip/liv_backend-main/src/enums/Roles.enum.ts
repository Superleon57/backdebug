export enum Roles {
  ADMIN = "admin",
  USER = "user",
  DELIVERY_MAN = "Role.livreur",
  COMMERCANT= "commercant",
}
