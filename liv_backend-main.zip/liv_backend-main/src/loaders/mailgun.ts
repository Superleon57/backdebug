import mailgun from "mailgun-js";

import config from "src/config";

export default async() => {
  /*return mailgun({
    domain: config.MAILGUN_DOMAIN,
    apiKey: config.MAILGUN_API_KEY,
    HOST: "api.mailgun.net",
  });*/
};
