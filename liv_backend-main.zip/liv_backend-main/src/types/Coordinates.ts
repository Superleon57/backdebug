export type Geoloc = {
  latitude: number;
  longitude: number;
};

export type MeiliSearchGeo = {
  lat: number;
  lng: number;
};
