export type Geopoint = [number, number];
