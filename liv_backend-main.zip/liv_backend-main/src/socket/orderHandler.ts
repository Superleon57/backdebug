const Order = (io, socket) => {};

export default Order;
