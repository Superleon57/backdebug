import { body, query } from 'express-validator';

export const statisticsSchema = [
];
