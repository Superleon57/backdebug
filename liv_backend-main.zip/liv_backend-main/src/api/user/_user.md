# User

User module is the entry point for retrieving user information.
It is used to get:
- a given profile (`/profile`)
- the list of all users (`/all`)

A user is retrieved by his `email` field.